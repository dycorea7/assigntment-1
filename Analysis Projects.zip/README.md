# Module 1: Kickstarter

Analyze a dataset consisting of 4,000 crowdfunding projects to discover hidden trends.

# Kickstarting with Excel

## Overview of Project

### Purpose
	The purpose of this project is to analyze the datasets of crowdfunding projects using excel based on different aspects.

## Analysis and Challenges

### Analysis of Outcomes Based on Launch Date
 	For the outcomes based on launch date of the projects, different codes should be used to pull data from the original woksheet.  

### Analysis of Outcomes Based on Goals
	For outcomes based on goals, using the formula to pull data from the original worksheet has been challenging.

### Challenges and Difficulties Encountered

## Results

- What are two conclusions you can draw about the Outcomes based on Launch Date?
	The outcomes based on launch date of the projects shows that the projects started on May to August have been successful.
	The outcomes based on launch date based on the months and years shows different graphs in different years.

- What can you conclude about the Outcomes based on Goals?
	The success rate decreases as the goal increases and the fail rate increases as the goal increases.

- What are some limitations of this dataset?
	This dataset has different category/subcategory that should be filtered to see the category of interest which is theoters/plays.
	The dataset for the outcome based on launch date shows months and the years can be filtered.

- What are some other possible tables and/or graphs that we could create?
	The ohter graphs based on the launch date based on years and month and the goals can be created. Two different data sets can be
	merged to analyze the all the aspects.
	
	